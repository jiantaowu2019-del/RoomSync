# RoomSync — Technical Design (decision brief, NOT finalized architecture)

This document intentionally stops short of prescribing a full schema. Codex should propose one and ask approval before implementation.

## Proposed shape
- React + TypeScript web UI; FastAPI JSON API; PostgreSQL persistence; simple local setup. These are proposed technologies, not irreversible commitments.
- One vertical slice must contain a working page, authenticated API endpoint(s), persistent storage, state transition logic and tests.
- Start with **one expense, one original payer, two authenticated users**, and an external receiver-provided payment link. Add group abstractions only as needed; avoid implementing future modules prematurely.

## Critical domain distinctions
- **Expense**: original submitted claim and its participant allocation(s).
- **Share / obligation**: a specific person's computed portion in the group ledger; it can be disputed separately from group bookkeeping.
- **Payment report**: payer says money was sent externally. This is an unverified statement, NOT a completed transfer.
- **Receipt confirmation**: authenticated recipient acknowledges receiving a specified amount; update payable balance atomically.
- **Settlement**: derived from all share balances being zero by approved recorded operations; preserve whether zero resulted from receipts or adjustments.
- **Dispute**: a contemporaneous statement with ongoing status; do not erase it upon a group vote.
- **Audit event**: append-only record for creation, proposed amendment, approval, report, receipt, reversal, appeal, vote, exit, etc.

## Preliminary transitions (request Codex to review)
- Share: UNPAID -> PAYMENT_REPORTED -> PARTIALLY_SETTLED or SETTLED (on authenticated recipient confirmation).
- Incorrect report: report can be rejected with explanation; it must not reduce balance.
- Payment reports are independent records, so multiple partial receipts and ongoing disputes can coexist.
- Expense settled is **derived**, not blindly set by a UI button: all its current valid shares have zero remaining amount.
- Dispute is an orthogonal axis, not a single mutually exclusive payment status.
- Historical values are not overwritten: modifications are append-only version/amendment events; projected current view is computed from them. A fully event-sourced system is NOT required for Slice 1.

## Security and reliability design questions for Codex
1. Explain the minimal authentication mechanism and anti-impersonation strategy.
2. Define scope checks on every expense, payment and audit read/write.
3. Enforce positive payment amounts, <= remaining due, currency consistency and integer cents.
4. Ensure confirmation and corresponding ledger updates occur in one database transaction.
5. Specify idempotency key design for retries; concurrent double confirmation must not double count.
6. Handle outbound payment URLs safely (known providers, validated receiver handles, no open redirect).
7. Add an append-only audit table/event structure and testing of immutable history.
8. Define how to correct a confirmation without silently deleting a previously recorded receipt.
9. No handling of bank details or actual payment credentials. Never infer success from link open/return.
10. Explain future group-member history boundaries without implementing unnecessary features yet.

## Architecture review gate
Do not code until the proposed schema, routes, transition table, safety measures, tests and unresolved choices have been shown to the product owner. Call out any PRD/technical conflict in plain language.
