# RoomSync — Acceptance and Test Plan (starter)

Acceptance criteria describe expected behavior independently of the code. Expand with tests when the corresponding slice is implemented. DO NOT assert unimplemented future features already pass.

## Slice 1: minimum end-to-end scenario
Given two authenticated users Alex and Sam, Alex creates a $60 expense shared equally. The initial share belonging to Sam is $30 and Alex is the intended recipient.

| ID | Scenario | Expected outcome |
|---|---|---|
| T01 | Create expense for $60, 2 equal participants | Sam's portion is exactly 3000 cents. |
| T02 | Sam opens external payment link and returns | No balance or payment-confirmation change. |
| T03 | Sam reports a $30 external payment | Status becomes reported/pending; unpaid balance not yet reduced. |
| T04 | Sam tries to confirm their own report as Alex | API returns forbidden; no ledger mutation. |
| T05 | Alex confirms $30 receipt | Sam remaining balance becomes zero and the expense can be settled if all valid payable shares are zero. |
| T06 | Repeat same confirmation request | No duplicate receipt, no negative balance, audit history remains coherent. |
| T07 | Two concurrent confirmation requests | Only one counted receipt. |
| T08 | Amount of zero, negative, or more than outstanding | Invalid request rejected with no ledger mutation. |
| T09 | Another nonparticipant reads or edits expense | Access denied. |
| T10 | An existing expense/payment is corrected | Original record remains visible in historical record; correction recorded as new event. Exact correction policy needs owner approval. |
| T11 | External receiver link is malformed or untrusted | Rejected; no open redirect. |
| T12 | Network/server failure during receipt confirmation | No half-updated balance; transaction is atomic. |

## Conditions to decide before Slice 1 implementation
- Whether partial payments are in Slice 1 or Slice 2; if included test $10 of $30 remains $20.
- Whether a consensual waiver counts toward settlement or the status is `Closed by adjustment` instead.
- Receiver payment-link provider, allowed URL shape, currency, manual confirmation copy.
- What a mistaken recipient confirmation may be reversed into and by whom.
- The smallest identity mechanism acceptable for a demo deployment.

## Slice 3 tests (future, not blockers for Slice 1)
- A normal authorized post appears without unanimous approval.
- Only relevant users can dispute and/or see protected conversation details.
- Group majority preference does not erase individual dissent.
- Disputed portions aren't subject to automated collection reminders.
- Posting/modifying a disputed or settled expense does not erase old versions.
- Vote eligibility, quorum, tie and abstention behavior follow owner-approved policy.

## Slice 4 and 5 tests (future)
- Reminder is not sent before consent or after appropriate opt-out/dispute.
- Duplicate scheduler runs don't send duplicate notices for same event window.
- Exit takes effect immediately without automatically reallocating unpaid shares.
- Ex-member retains authorized historical access/export but not unrelated new activity.

## Definition of Done for each slice
- User story works in running app end-to-end.
- All tests relevant to current slice have been run and pass; list skipped tests explicitly.
- New endpoints check authorization on the server.
- Migration, developer startup instructions and sample environment configuration are present.
- Important state changes produce coherent audit events.
- PRD and design updates reflect the actual behavior, with unresolved decisions flagged.
