# RoomSync starter pack

Documents prepared for a Codex-assisted vertical slice workflow.

- `docs/PRD.md`: product scope, principles and all 12 discussed topics with explicit decision status.
- `docs/DESIGN.md`: technical design guidance and unresolved architectural choices (NOT finalized schema).
- `docs/TEST_PLAN.md`: acceptance tests written independently of implementation.
- `AGENTS.md`: persistent Codex coding and safety rules.
- `CODEX_START_PROMPT.md`: first design-only message to give Codex.

Next: copy this directory into your intended git repository, open it in Codex, and send the contents of `CODEX_START_PROMPT.md`. Review the proposed schema and transitions before allowing implementation. No application code is included yet.
